# Backend Requirements for PowerBI Dashboard Integration

## Overview
This document outlines the backend requirements for the PowerBI dashboard creation and visualization system that integrates with SharePoint and Microsoft services.

## 1. Database Schema Extensions (Supabase Tables)

### Add to existing `workflows` table
```sql
ALTER TABLE workflows ADD COLUMN powerbi_dashboard_id TEXT;
ALTER TABLE workflows ADD COLUMN powerbi_workspace_id TEXT;
ALTER TABLE workflows ADD COLUMN sharepoint_site_url TEXT;
ALTER TABLE workflows ADD COLUMN dashboard_created_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE workflows ADD COLUMN dashboard_status TEXT DEFAULT 'not_created'; -- not_created, creating, created, failed
```

### `powerbi_dashboards` table
```sql
CREATE TABLE powerbi_dashboards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id UUID REFERENCES workflows(id),
  dashboard_id TEXT NOT NULL, -- PowerBI dashboard ID
  workspace_id TEXT NOT NULL, -- PowerBI workspace ID
  dashboard_name TEXT NOT NULL,
  dashboard_url TEXT, -- PowerBI embed URL
  
  -- SharePoint configuration
  sharepoint_site_url TEXT NOT NULL,
  sharepoint_list_name TEXT,
  
  -- Dashboard configuration
  refresh_schedule TEXT DEFAULT 'PT15M', -- ISO 8601 duration (15 minutes)
  last_refresh TIMESTAMP WITH TIME ZONE,
  next_refresh TIMESTAMP WITH TIME ZONE,
  
  -- Metrics and status
  total_visualizations INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active', -- active, inactive, error
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### `dashboard_metrics` table
```sql
CREATE TABLE dashboard_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dashboard_id UUID REFERENCES powerbi_dashboards(id),
  metric_date DATE NOT NULL,
  
  -- Workflow performance metrics
  total_runs INTEGER DEFAULT 0,
  successful_runs INTEGER DEFAULT 0,
  failed_runs INTEGER DEFAULT 0,
  average_duration_seconds INTEGER DEFAULT 0,
  records_processed INTEGER DEFAULT 0,
  
  -- Data quality metrics
  data_quality_score DECIMAL(5,2), -- 0-100 score
  validation_errors INTEGER DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(dashboard_id, metric_date)
);
```

## 2. Microsoft Graph API Integration

### Authentication Setup
```javascript
// Required environment variables
const MICROSOFT_CLIENT_ID = process.env.MICROSOFT_CLIENT_ID;
const MICROSOFT_CLIENT_SECRET = process.env.MICROSOFT_CLIENT_SECRET;
const MICROSOFT_TENANT_ID = process.env.MICROSOFT_TENANT_ID;

// OAuth 2.0 configuration for Microsoft Graph
const msalConfig = {
  auth: {
    clientId: MICROSOFT_CLIENT_ID,
    clientSecret: MICROSOFT_CLIENT_SECRET,
    authority: `https://login.microsoftonline.com/${MICROSOFT_TENANT_ID}`
  }
};

// Required permissions/scopes
const requiredScopes = [
  'https://analysis.windows.net/powerbi/api/Dashboard.ReadWrite.All',
  'https://analysis.windows.net/powerbi/api/Dataset.ReadWrite.All',
  'https://graph.microsoft.com/Sites.ReadWrite.All',
  'https://graph.microsoft.com/Files.ReadWrite.All'
];
```

### PowerBI REST API Integration
```javascript
// Base PowerBI API configuration
const POWERBI_BASE_URL = 'https://api.powerbi.com/v1.0/myorg';

// Key endpoints to integrate:
// POST /groups/{groupId}/dashboards
// POST /groups/{groupId}/datasets  
// POST /groups/{groupId}/datasets/{datasetId}/refreshes
// GET /groups/{groupId}/dashboards/{dashboardId}
// POST /groups/{groupId}/reports/{reportId}/Clone
```

### SharePoint API Integration
```javascript
// SharePoint REST API endpoints
const SHAREPOINT_BASE_URL = 'https://{tenant}.sharepoint.com';

// Key endpoints:
// GET /sites/{site-id}/lists
// GET /sites/{site-id}/lists/{list-id}/items
// POST /sites/{site-id}/lists/{list-id}/items
// GET /sites/{site-id}/drives/{drive-id}/items
```

## 3. API Endpoints Needed

### PowerBI Dashboard Management
- `POST /api/powerbi/create-dashboard` - Create new PowerBI dashboard
- `GET /api/powerbi/dashboards/:workflow_id` - Get dashboard for workflow
- `PUT /api/powerbi/dashboards/:id` - Update dashboard configuration
- `DELETE /api/powerbi/dashboards/:id` - Remove PowerBI dashboard
- `POST /api/powerbi/dashboards/:id/refresh` - Manually trigger data refresh

### SharePoint Integration
- `POST /api/sharepoint/authenticate` - Authenticate with SharePoint
- `GET /api/sharepoint/sites` - List available SharePoint sites
- `GET /api/sharepoint/sites/:site_id/lists` - Get lists from SharePoint site
- `POST /api/sharepoint/sites/:site_id/create-list` - Create new SharePoint list for data

### Dashboard Data & Metrics
- `GET /api/dashboards/:id/metrics` - Get dashboard performance metrics
- `POST /api/dashboards/:id/metrics` - Update dashboard metrics
- `GET /api/dashboards/:id/embed-token` - Get PowerBI embed token
- `GET /api/dashboards/:id/data-sources` - Get dashboard data sources

## 4. Supabase Edge Functions

### `create-powerbi-dashboard` function
```typescript
// Input: workflow_id, sharepoint_config, dashboard_config
// Process:
// 1. Authenticate with Microsoft Graph API
// 2. Create PowerBI workspace (if needed)
// 3. Create dataset from workflow data structure
// 4. Create dashboard with default visualizations
// 5. Configure data refresh schedule
// 6. Store dashboard configuration in database
// 7. Return dashboard embed URL and configuration
```

### `refresh-dashboard-data` function (scheduled)
```typescript
// Runs every 15 minutes
// Process:
// 1. Get all active dashboards with scheduled refresh
// 2. For each dashboard:
//    - Fetch latest workflow run data from Airflow
//    - Update SharePoint data source
//    - Trigger PowerBI dataset refresh
//    - Update dashboard_metrics table
//    - Handle any refresh errors
```

### `sync-workflow-metrics` function
```typescript
// Input: workflow_id, run_data
// Process:
// 1. Calculate workflow performance metrics
// 2. Update dashboard_metrics table
// 3. Push metrics to PowerBI dataset
// 4. Trigger dashboard refresh if needed
```

### `generate-dashboard-template` function
```typescript
// Input: workflow_type, data_structure
// Process:
// 1. Analyze workflow data patterns
// 2. Generate appropriate visualizations:
//    - Success rate trends (line chart)
//    - Daily processing volume (bar chart)
//    - Error analysis (pie chart)
//    - Performance metrics (KPI cards)
// 3. Create PowerBI template JSON
// 4. Return dashboard configuration
```

## 5. PowerBI Template Configurations

### Default Dashboard Layout
```json
{
  "name": "{workflow_name} - Performance Dashboard",
  "pages": [
    {
      "name": "Overview",
      "visualizations": [
        {
          "type": "kpi",
          "title": "Success Rate",
          "dataSource": "workflow_metrics",
          "measure": "success_percentage"
        },
        {
          "type": "lineChart",
          "title": "Daily Success Rate Trend",
          "xAxis": "date",
          "yAxis": "success_rate"
        },
        {
          "type": "barChart", 
          "title": "Records Processed",
          "xAxis": "date",
          "yAxis": "records_processed"
        }
      ]
    },
    {
      "name": "Data Analysis",
      "visualizations": [
        {
          "type": "table",
          "title": "Recent Workflow Runs",
          "dataSource": "workflow_runs",
          "columns": ["run_date", "status", "duration", "records_processed"]
        }
      ]
    }
  ]
}
```

## 6. Security & Authentication

### Row Level Security (RLS)
```sql
-- Users can only see dashboards for their workflows
ALTER TABLE powerbi_dashboards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own dashboards" ON powerbi_dashboards
  FOR SELECT USING (
    workflow_id IN (
      SELECT id FROM workflows WHERE user_id = auth.uid()
    )
  );
```

### Microsoft Authentication Flow
1. **User initiates SharePoint connection**
2. **Backend redirects to Microsoft OAuth**
3. **User grants permissions**
4. **Backend receives authorization code**
5. **Exchange code for access/refresh tokens**
6. **Store encrypted tokens in Supabase secrets**
7. **Use tokens for API calls with automatic refresh**

## 7. Environment Variables

```bash
# Microsoft Graph API
MICROSOFT_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
MICROSOFT_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxx
MICROSOFT_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# PowerBI Service Principal
POWERBI_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
POWERBI_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxx

# SharePoint Configuration
SHAREPOINT_BASE_URL=https://yourcompany.sharepoint.com
SHAREPOINT_APP_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx

# Webhook endpoints for real-time updates
POWERBI_WEBHOOK_SECRET=your_webhook_secret_key
```

## 8. Data Flow Architecture

```
Workflow Execution (Airflow) 
    ↓ (trigger)
Webhook to Supabase Edge Function
    ↓ (process)
Update dashboard_metrics table
    ↓ (sync)
Push data to SharePoint List
    ↓ (refresh)
PowerBI Dataset Refresh
    ↓ (update)
Dashboard Visualizations
```

## 9. Implementation Priority

1. **Phase 1**: Microsoft Graph authentication and basic API integration
2. **Phase 2**: PowerBI workspace and dashboard creation
3. **Phase 3**: SharePoint data source integration
4. **Phase 4**: Automated data refresh and metrics sync
5. **Phase 5**: Advanced visualizations and custom templates

## 10. Error Handling & Monitoring

### Common Error Scenarios
- **Microsoft API rate limiting**
- **SharePoint authentication failures**
- **PowerBI service unavailability**
- **Data schema mismatches**
- **Insufficient permissions**

### Monitoring Requirements
- API call success/failure rates
- Dashboard creation time
- Data refresh latency
- User authentication status
- Token expiration tracking

## Notes for Backend Team

- Use Microsoft Graph SDK for .NET or Node.js for robust API integration
- Implement proper token refresh logic to handle expired credentials
- Consider implementing circuit breakers for external API calls
- Store all sensitive tokens encrypted in Supabase secrets
- Implement comprehensive logging for debugging Microsoft API issues
- Follow Microsoft's PowerBI embedding best practices for security