# Backend Requirements for Airflow DAG Management System

## Overview
This document outlines the backend requirements for the Airflow DAG creation and deployment system that needs to be implemented by the backend team.

## 1. Database Schema (Supabase Tables)

### `workflows` table
```sql
CREATE TABLE workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  category TEXT,
  status TEXT DEFAULT 'pending', -- pending, analyzing, deploying, deployed, failed
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_id UUID REFERENCES auth.users(id),
  
  -- Workflow configuration
  workflow_config JSONB, -- stores all form data from BuildWorkflow
  matched_workflows JSONB, -- stores similar workflows found by AI
  selected_template_id TEXT, -- which GitHub workflow was selected
  
  -- Airflow specific
  dag_id TEXT UNIQUE,
  airflow_config JSONB,
  deployment_status TEXT DEFAULT 'not_deployed' -- not_deployed, deploying, deployed, failed
);
```

### `dag_runs` table  
```sql
CREATE TABLE dag_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id UUID REFERENCES workflows(id),
  dag_id TEXT NOT NULL,
  run_id TEXT NOT NULL,
  state TEXT NOT NULL, -- success, failed, running, queued
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  duration INTERVAL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### `task_instances` table
```sql
CREATE TABLE task_instances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dag_run_id UUID REFERENCES dag_runs(id),
  task_id TEXT NOT NULL,
  state TEXT NOT NULL,
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  duration INTERVAL,
  operator_type TEXT,
  log_output TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### `github_workflows` table
```sql
CREATE TABLE github_workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_name TEXT NOT NULL,
  description TEXT,
  github_url TEXT,
  technologies TEXT[], -- array of technology names
  problem_set TEXT,
  complexity TEXT, -- Low, Medium, High
  code_content TEXT, -- stored workflow code
  created_for TEXT, -- which customer
  tags TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## 2. API Endpoints Needed

### Workflow Management
- `POST /api/workflows` - Create new workflow from form submission
- `GET /api/workflows` - List user's workflows 
- `GET /api/workflows/:id` - Get specific workflow details
- `PUT /api/workflows/:id` - Update workflow
- `DELETE /api/workflows/:id` - Delete workflow

### AI Analysis & Matching
- `POST /api/workflows/:id/analyze` - Trigger AI analysis of workflow
- `GET /api/workflows/:id/matches` - Get similar GitHub workflows
- `POST /api/workflows/:id/select-template` - Select a GitHub template to use

### Airflow Integration
- `POST /api/airflow/deploy-dag` - Deploy DAG to Airflow
- `GET /api/airflow/dag/:dag_id/status` - Get DAG deployment status
- `GET /api/airflow/dag/:dag_id/runs` - Get DAG run history
- `GET /api/airflow/dag/:dag_id/tasks` - Get task instances
- `POST /api/airflow/dag/:dag_id/trigger` - Manually trigger DAG run
- `DELETE /api/airflow/dag/:dag_id` - Remove DAG from Airflow

### GitHub Integration  
- `GET /api/github/workflows` - Search GitHub for similar workflows
- `GET /api/github/workflows/:id/code` - Get specific workflow code
- `POST /api/github/workflows/index` - Index new workflows from GitHub

## 3. External API Integrations

### Airflow REST API
```javascript
// Base configuration
const AIRFLOW_BASE_URL = process.env.AIRFLOW_BASE_URL;
const AIRFLOW_AUTH = {
  username: process.env.AIRFLOW_USERNAME,
  password: process.env.AIRFLOW_PASSWORD
};

// Key endpoints to integrate:
// GET /api/v1/dags/{dag_id}
// POST /api/v1/dags/{dag_id}/dagRuns  
// GET /api/v1/dags/{dag_id}/dagRuns
// GET /api/v1/dags/{dag_id}/tasks
// PUT /api/v1/dags/{dag_id} (pause/unpause)
```

### GitHub API
```javascript
// For searching and retrieving workflow templates
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_ORG = 'CollationAI'; // or wherever workflows are stored

// Key endpoints:
// GET /repos/{owner}/{repo}/contents/{path}
// GET /search/code?q={query}+org:{org}
// GET /repos/{owner}/{repo}/contents
```

## 4. Background Jobs (Supabase Edge Functions)

### `analyze-workflow` function
- Processes workflow form submission
- Extracts keywords and technologies
- Searches GitHub for similar workflows  
- Ranks matches by similarity
- Updates workflow status

### `deploy-dag` function
- Takes selected GitHub template
- Generates custom DAG Python code
- Deploys to Airflow via REST API
- Monitors deployment status
- Updates database with results

### `sync-airflow-status` function (scheduled)
- Runs every 5 minutes
- Syncs DAG run status from Airflow
- Updates local database with latest runs
- Handles status changes and notifications

### `index-github-workflows` function (scheduled)
- Runs daily
- Scans GitHub repositories for new workflows
- Extracts metadata and indexes in database
- Updates similarity matching capabilities

## 5. Environment Variables Needed

```bash
# Airflow Integration
AIRFLOW_BASE_URL=https://airflow.collation.ai
AIRFLOW_USERNAME=api_user
AIRFLOW_PASSWORD=secure_password

# GitHub Integration  
GITHUB_TOKEN=ghp_xxxxxxxxxxxx
GITHUB_ORG=CollationAI
GITHUB_WORKFLOWS_REPO=workflows

# AI/ML Services (if using external AI)
OPENAI_API_KEY=sk-xxxxxxxxxxxx
# OR
ANTHROPIC_API_KEY=ant-xxxxxxxxxxxx

# Notification Services
SENDGRID_API_KEY=SG.xxxxxxxxxxxx
SLACK_WEBHOOK_URL=https://hooks.slack.com/xxxxxxxxxxxx
```

## 6. Security Considerations

### Row Level Security (RLS) Policies
```sql
-- Users can only see their own workflows
ALTER TABLE workflows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own workflows" ON workflows
  FOR SELECT USING (auth.uid() = user_id);

-- Similar policies for dag_runs and task_instances
```

### API Authentication
- All Airflow API calls must be authenticated
- GitHub API calls require proper token permissions
- Rate limiting on external API calls
- Input validation on all workflow submissions

## 7. Monitoring & Observability

### Metrics to Track
- Workflow creation rate
- DAG deployment success rate  
- Average deployment time
- GitHub API rate limit usage
- Airflow connectivity status
- Background job execution times

### Logging Requirements
- All API calls to external services
- DAG deployment attempts and results
- Workflow analysis results
- Error conditions and retries

## 8. Implementation Priority

1. **Phase 1**: Basic workflow CRUD operations
2. **Phase 2**: GitHub workflow search and matching
3. **Phase 3**: Airflow DAG deployment
4. **Phase 4**: Real-time status monitoring
5. **Phase 5**: Advanced analytics and optimization

## Notes for Backend Team

- Use Supabase client libraries for database operations
- Implement proper error handling for all external API calls
- Consider implementing circuit breakers for external services
- Use TypeScript for type safety across the system
- Implement comprehensive logging for debugging
- Consider implementing webhook endpoints for Airflow callbacks