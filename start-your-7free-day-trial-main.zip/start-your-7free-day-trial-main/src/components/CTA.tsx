import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const CTA = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Ready to Transform Your{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Investment Reporting?
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-4">
            Join family offices already saving thousands in operational costs while getting better investment insights.
          </p>
          <p className="text-lg font-semibold text-foreground mb-12">
            <strong>No system changes. No migration. No risk.</strong>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button size="lg" className="text-lg px-8 py-6">
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6">
              Watch Demo Video
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="text-center bg-background/50 border-border/50">
            <CardContent className="p-8">
              <div className="text-4xl font-bold text-primary mb-2">70%</div>
              <div className="text-muted-foreground">Cost Reduction</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-background/50 border-border/50">
            <CardContent className="p-8">
              <div className="text-4xl font-bold text-primary mb-2">2-4 Weeks</div>
              <div className="text-muted-foreground">Implementation</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-background/50 border-border/50">
            <CardContent className="p-8">
              <div className="text-4xl font-bold text-primary mb-2">99.9%</div>
              <div className="text-muted-foreground">Data Accuracy</div>
            </CardContent>
          </Card>
        </div>

        {/* Trust Footer */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Trusted by Family Offices • Enterprise Security • 24/7 Support • SOC 2 Compliant
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA;