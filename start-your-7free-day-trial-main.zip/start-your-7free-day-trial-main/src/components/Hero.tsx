import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Database, Zap, TrendingUp, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import mediaOutlets from "@/assets/media-outlets.png";

const Hero = () => {
  const { toast } = useToast();

  const handleScheduleDemo = () => {
    // Navigate to dedicated demo page with Calendly
    window.location.href = '/schedule-demo';
  };
  return (
    <section className="bg-gradient-to-br from-background to-secondary/20 py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">
            We Solve{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Data Headaches
            </span>{" "}
            for Wealth Managers
          </h1>
          
          <p className="text-xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
            We reduce operational costs, improve workflow efficiencies by Aggregating Financial Data via AI Bots from your{" "}
            <span className="font-semibold text-primary">&quot;existing technology stack&quot;</span>, and bring it into your{" "}
            <span className="font-semibold text-primary">&quot;fully accessible&quot;</span> centralized Data Warehouse
          </p>

          {/* Core Services */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="flex flex-col items-center p-6 bg-primary/5 rounded-lg border border-primary/20">
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                <Database className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Data Warehousing</h3>
              <span className="text-sm text-muted-foreground text-center">Secure data aggregation and storage with automated sync</span>
            </div>
            <div className="flex flex-col items-center p-6 bg-warning/5 rounded-lg border border-warning/20">
              <div className="w-16 h-16 bg-warning/10 rounded-lg flex items-center justify-center mb-3">
                <Zap className="w-8 h-8 text-warning" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Workflow Automation</h3>
              <span className="text-sm text-muted-foreground text-center">AI-powered automation for business processes and data flows</span>
            </div>
            <div className="flex flex-col items-center p-6 bg-success/5 rounded-lg border border-success/20">
              <div className="w-16 h-16 bg-success/10 rounded-lg flex items-center justify-center mb-3">
                <TrendingUp className="w-8 h-8 text-success" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Data Analytics</h3>
              <span className="text-sm text-muted-foreground text-center">Investment insights and reporting with real-time monitoring</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link to="/free-trial">
              <Button size="lg" className="text-lg px-8 py-6">
                Start Free Trial →
              </Button>
            </Link>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 py-6"
              onClick={handleScheduleDemo}
            >
              Schedule Demo
            </Button>
          </div>

          {/* Media Outlets */}
          <div className="text-center">
            <p className="text-muted-foreground text-sm mb-6">
              Proudly featured on
            </p>
            <div className="flex justify-center">
              <img 
                src={mediaOutlets} 
                alt="Featured on The Wealth Mosaic, CityWire, Forbes, RIABiz, Wealth Briefing, KITCES, and FOTechHub" 
                className="max-w-full h-auto opacity-70 hover:opacity-100 transition-opacity duration-300"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;