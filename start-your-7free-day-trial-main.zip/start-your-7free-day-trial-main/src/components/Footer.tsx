const Footer = () => {
  return (
    <footer className="bg-background border-t border-border/50 py-8">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-center">
          <div className="text-center">
            <div className="text-xl font-bold text-foreground mb-2">
              collation.ai
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 Collation.AI • Transform Your Investment Data
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;