import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Database, Workflow, BarChart3, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";

interface PillarProgressProps {
  title: string;
  description: string;
  progress: number;
  icon: React.ComponentType<any>;
  status: "not-started" | "in-progress" | "completed";
  steps: {
    name: string;
    completed: boolean;
  }[];
  actionButton?: {
    text: string;
    link: string;
  };
}

const PillarProgress = ({ title, description, progress, icon: Icon, status, steps, actionButton }: PillarProgressProps) => {
  const getStatusBadge = () => {
    switch (status) {
      case "completed":
        return <Badge className="bg-success text-success-foreground">Completed</Badge>;
      case "in-progress":
        return <Badge className="bg-primary text-primary-foreground">In Progress</Badge>;
      case "not-started":
        return <Badge variant="outline">Not Started</Badge>;
      default:
        return <Badge variant="outline">Not Started</Badge>;
    }
  };

  return (
    <Card className="border-border/50 hover:shadow-lg transition-all duration-300">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon className="w-6 h-6 text-primary" />
            </div>
            <div>
              <CardTitle className="text-xl">{title}</CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
          </div>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Progress</span>
              <span className="text-sm text-muted-foreground">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-foreground">Setup Steps</h4>
            {steps.map((step, index) => (
              <div key={index} className="flex items-center space-x-2">
                <CheckCircle 
                  className={`w-4 h-4 ${step.completed ? 'text-success' : 'text-muted-foreground'}`} 
                />
                <span className={`text-sm ${step.completed ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {step.name}
                </span>
              </div>
            ))}
          </div>
          
          {actionButton && (
            <div className="mt-4">
              <Link to={actionButton.link}>
                <Button className="w-full" variant="outline">
                  {actionButton.text}
                </Button>
              </Link>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PillarProgress;