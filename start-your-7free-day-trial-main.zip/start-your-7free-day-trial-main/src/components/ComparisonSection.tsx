import { X, CheckCircle } from "lucide-react";

const ComparisonSection = () => {
  const traditional = [
    { feature: "$50,000+ annual licensing", negative: true },
    { feature: "$200,000+ implementation costs", negative: true },
    { feature: "6-12 months setup time", negative: true },
    { feature: "Dedicated IT team required", negative: true },
    { feature: "Data migration complexity", negative: true }
  ];

  const collation = [
    { feature: "$1,200-12,000 annual cost", positive: true },
    { feature: "No implementation fees", positive: true },
    { feature: "2-4 weeks to go live", positive: true },
    { feature: "No technical team needed", positive: true },
    { feature: "No system changes required", positive: true }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Compare to Traditional Solutions
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Traditional Solutions */}
          <div className="bg-red-50 rounded-lg p-8 border border-red-200">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center">
              Traditional Portfolio Systems
            </h3>
            <ul className="space-y-4">
              {traditional.map((item, index) => (
                <li key={index} className="flex items-center gap-3">
                  <X className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <span className="text-muted-foreground">{item.feature}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Collation.AI */}
          <div className="bg-green-50 rounded-lg p-8 border border-green-200">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center">
              Collation.AI Platform
            </h3>
            <ul className="space-y-4">
              {collation.map((item, index) => (
                <li key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-muted-foreground">{item.feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;