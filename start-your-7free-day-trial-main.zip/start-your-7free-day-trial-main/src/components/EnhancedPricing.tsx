import { Button } from "@/components/ui/button";
import { CheckCircle, Star } from "lucide-react";
import { Link } from "react-router-dom";

const EnhancedPricing = () => {
  const familyOfficePlans = [
    {
      name: "Single Family Offices",
      price: "$100-500",
      period: "/month",
      description: "Complete three-service platform optimized for single family wealth management operations",
      features: [
        "Data Warehousing: Secure family data storage",
        "Workflow Automation: Custom family workflows", 
        "Data Analytics: Family-specific performance reports",
        "Private investment tracking across all services",
        "Direct family member portal access"
      ]
    },
    {
      name: "Multi Family Offices", 
      price: "$500-1,000",
      period: "/month",
      description: "Scalable three-service platform managing multiple families with segregated operations across all services",
      features: [
        "Data Warehousing: Multi-tenant data architecture",
        "Workflow Automation: Bulk processing capabilities",
        "Data Analytics: Client-specific dashboards", 
        "Automated client reporting distribution",
        "Advanced compliance monitoring across all services"
      ],
      popular: true
    }
  ];

  const standardPlans = [
    {
      name: "Starter",
      price: "$100",
      period: "per month",
      description: "Perfect for small single family offices getting started",
      features: [
        "Up to 5 data sources",
        "Basic ABOR to IBOR conversion",
        "Monthly performance reports",
        "Email support",
        "Standard data warehouse",
        "Basic AI bot monitoring"
      ]
    },
    {
      name: "Professional",
      price: "$500", 
      period: "per month",
      description: "Comprehensive solution for established family offices",
      features: [
        "Unlimited data sources",
        "Advanced ABOR to IBOR conversion",
        "Real-time reporting & dashboards",
        "Priority support",
        "Advanced data warehouse",
        "AI bot supervision portal",
        "Custom reporting schedules",
        "API access"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: "$1,000",
      period: "per month", 
      description: "Full-scale solution for multi-family offices",
      features: [
        "Multi-tenant architecture",
        "Advanced AI bot management",
        "White-label reporting",
        "Dedicated account manager",
        "Enterprise data warehouse",
        "24/7 phone support",
        "Custom integrations",
        "SLA guarantees",
        "Compliance reporting"
      ]
    }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        {/* Family Office Plans */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose the plan that fits your family office needs. All plans include our core AI automation and data transformation features.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
          {familyOfficePlans.map((plan, index) => (
            <div 
              key={index}
              className={`bg-background rounded-lg p-8 shadow-lg border-2 ${
                plan.popular ? 'border-primary' : 'border-border'
              } relative`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-1">
                    <Star className="w-4 h-4" />
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                <div className="text-4xl font-bold text-foreground mb-2">
                  {plan.price}
                  <span className="text-lg text-muted-foreground">{plan.period}</span>
                </div>
                <p className="text-muted-foreground">{plan.description}</p>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link to="/free-trial" className="block">
                <Button 
                  className={`w-full ${
                    plan.popular ? 'bg-primary hover:bg-primary/90' : ''
                  }`}
                  variant={plan.popular ? 'default' : 'outline'}
                >
                  Get Started
                </Button>
              </Link>
            </div>
          ))}
        </div>

        {/* Standard Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {standardPlans.map((plan, index) => (
            <div 
              key={index}
              className={`bg-background rounded-lg p-6 shadow-lg border-2 ${
                plan.popular ? 'border-primary' : 'border-border'
              } relative`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-foreground mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-foreground mb-2">
                  {plan.price}
                  <span className="text-sm text-muted-foreground block">{plan.period}</span>
                </div>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link to="/free-trial" className="block">
                <Button 
                  className="w-full"
                  variant={plan.popular ? 'default' : 'outline'}
                >
                  Get Started
                </Button>
              </Link>
            </div>
          ))}
        </div>

        {/* Custom Solutions */}
        <div className="text-center mt-16 p-8 bg-background rounded-lg border">
          <h3 className="text-2xl font-bold text-foreground mb-4">Need Custom Solutions?</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Our Services division offers custom development, consulting, and specialized workflows at $150/hour. 
            Perfect for unique requirements that go beyond our standard platform capabilities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline">Contact Sales</Button>
            <Button>Schedule Consultation</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EnhancedPricing;