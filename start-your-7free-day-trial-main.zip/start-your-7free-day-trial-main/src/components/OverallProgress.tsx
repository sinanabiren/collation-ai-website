import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface OverallProgressProps {
  totalProgress: number;
  completedPillars: number;
  totalPillars: number;
  daysRemaining: number;
}

const OverallProgress = ({ totalProgress, completedPillars, totalPillars, daysRemaining }: OverallProgressProps) => {
  return (
    <Card className="bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
      <CardContent className="p-8">
        <div className="text-center space-y-6">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">
              7-Day Free Trial Progress
            </h2>
            <p className="text-muted-foreground">
              {daysRemaining} days remaining to complete your setup
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-foreground">Overall Completion</span>
              <span className="text-sm text-muted-foreground">{totalProgress}%</span>
            </div>
            <Progress value={totalProgress} className="h-4" />
          </div>

          <div className="grid grid-cols-3 gap-6 max-w-md mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{completedPillars}</div>
              <div className="text-xs text-muted-foreground">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-warning">{totalPillars - completedPillars}</div>
              <div className="text-xs text-muted-foreground">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">{daysRemaining}</div>
              <div className="text-xs text-muted-foreground">Days Left</div>
            </div>
          </div>

          {totalProgress === 100 && (
            <div className="p-4 bg-success/10 border border-success/20 rounded-lg">
              <p className="text-success font-medium">
                🎉 Congratulations! You've completed your setup. Ready to upgrade to a paid plan?
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default OverallProgress;