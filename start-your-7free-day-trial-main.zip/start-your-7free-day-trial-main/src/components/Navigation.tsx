import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Settings, LogOut } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  
  // Check if we're on the trial dashboard to show user info
  const isTrialDashboard = location.pathname === "/trial-dashboard";

  const navItems = [
    { name: "Home", href: "/" },
    { name: "Get Started", href: "/free-trial" },
  ];

  return (
    <nav className="bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border/40 sticky top-0 z-50">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-xl font-bold text-foreground">
              collation.ai
            </Link>
            {isTrialDashboard && (
              <Badge className="bg-success/10 text-success hover:bg-success/20">
                Trial Active
              </Badge>
            )}
          </div>

          {/* Desktop Navigation */}
          {!isTrialDashboard && (
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </div>
          )}

          {/* Right side - Trial Dashboard vs Regular */}
          <div className="flex items-center space-x-4">
            {isTrialDashboard ? (
              // Trial Dashboard - User Info
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-sm font-medium text-foreground">John Smith</div>
                  <div className="text-xs text-muted-foreground">Smith Family Office</div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              // Regular Navigation - Sign In/Demo buttons
              <>
                <div className="hidden md:flex items-center space-x-4">
                  <Link to="/sign-in">
                    <Button variant="ghost">Sign In</Button>
                  </Link>
                  <Link to="/schedule-demo">
                    <Button variant="outline">Schedule Demo</Button>
                  </Link>
                  <Link to="/free-trial">
                    <Button>Start Free Trial</Button>
                  </Link>
                </div>

                {/* Mobile menu button */}
                <div className="md:hidden">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsOpen(!isOpen)}
                  >
                    {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && !isTrialDashboard && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="block px-3 py-2 text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              <div className="pt-4 space-y-2">
                <Link to="/sign-in" className="block">
                  <Button variant="ghost" className="w-full justify-start">
                    Sign In
                  </Button>
                </Link>
                <Link to="/schedule-demo" className="block">
                  <Button variant="outline" className="w-full justify-start">
                    Schedule Demo
                  </Button>
                </Link>
                <Link to="/free-trial" className="block">
                  <Button className="w-full justify-start">Start Free Trial</Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;