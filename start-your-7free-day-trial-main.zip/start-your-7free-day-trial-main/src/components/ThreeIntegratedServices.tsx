import { Database, Zap, TrendingUp, Shield, CheckCircle, Clock } from "lucide-react";

const ThreeIntegratedServices = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Three Integrated Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Complete investment operations platform with data warehousing, workflow automation, and analytics
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Data Warehousing */}
          <div className="text-center">
            <div className="w-20 h-20 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
              <Database className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Data Warehousing</h3>
            <p className="text-lg text-muted-foreground mb-8">
              Secure, centralized data storage and management
            </p>
            
            <div className="space-y-6 text-left">
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary" />
                  Secure Data Storage
                </h4>
                <p className="text-muted-foreground text-sm">
                  Enterprise-grade data warehouse with 99.9% uptime and bank-level security.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Automated Data Sync
                </h4>
                <p className="text-muted-foreground text-sm">
                  Real-time synchronization across all your financial systems and data sources.
                </p>
              </div>
            </div>
          </div>

          {/* Workflow Automation */}
          <div className="text-center">
            <div className="w-20 h-20 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-6">
              <Zap className="w-10 h-10 text-warning" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Workflow Automation</h3>
            <p className="text-lg text-muted-foreground mb-8">
              AI-powered automation for business processes
            </p>
            
            <div className="space-y-6 text-left">
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-warning" />
                  AI-Powered Workflows
                </h4>
                <p className="text-muted-foreground text-sm">
                  Intelligent automation that learns from your processes and optimizes over time.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-warning" />
                  Custom Automation Rules
                </h4>
                <p className="text-muted-foreground text-sm">
                  Build sophisticated workflows with triggers, conditions, and automated actions.
                </p>
              </div>
            </div>
          </div>

          {/* Data Analytics */}
          <div className="text-center">
            <div className="w-20 h-20 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-6">
              <TrendingUp className="w-10 h-10 text-success" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Data Analytics</h3>
            <p className="text-lg text-muted-foreground mb-8">
              Investment insights and reporting capabilities
            </p>
            
            <div className="space-y-6 text-left">
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-success" />
                  Investment Reporting
                </h4>
                <p className="text-muted-foreground text-sm">
                  Generate comprehensive investment reports and performance analytics automatically.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-success" />
                  Real-time Monitoring
                </h4>
                <p className="text-muted-foreground text-sm">
                  Continuous monitoring with alerts and automated compliance checks.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ThreeIntegratedServices;