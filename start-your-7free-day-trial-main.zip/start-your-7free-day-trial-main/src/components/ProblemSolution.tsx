import { AlertTriangle, CheckCircle, Clock, DollarSign, FileText, Target } from "lucide-react";

const ProblemSolution = () => {
  const challenges = [
    {
      icon: Clock,
      text: "Staff waste 3+ hours daily aggregating disconnected data"
    },
    {
      icon: Clock,
      text: "Manual processes cause 2+ weeks delays in report preparation"
    },
    {
      icon: FileText,
      text: "Data entry takes 15+ hours per week for external assets"
    },
    {
      icon: AlertTriangle,
      text: "Poor analytics due to overpriced systems or Excel spreadsheets"
    },
    {
      icon: DollarSign,
      text: "Expensive portfolio systems require duplicate data entry"
    },
    {
      icon: Target,
      text: "Manual reconciliation across multiple portals and systems"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Problem */}
          <div>
            <h2 className="text-4xl font-bold text-foreground mb-6">
              Stop the Data Headaches
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Family offices struggle with fragmented data across systems. We solve this without changing your technology stack.
            </p>
            
            <h3 className="text-2xl font-semibold text-foreground mb-6">Current Challenges</h3>
            <div className="space-y-4">
              {challenges.map((challenge, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <challenge.icon className="w-3 h-3 text-red-600" />
                  </div>
                  <p className="text-muted-foreground">{challenge.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Solution */}
          <div>
            <h2 className="text-4xl font-bold text-foreground mb-6">
              Complete Three-Service Platform
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Integrated data warehousing, workflow automation, and analytics designed specifically for family office operations
            </p>
            
            <div className="bg-primary/5 rounded-lg p-6 border border-primary/20">
              <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <CheckCircle className="w-6 h-6 text-primary" />
                Our Unique Value Proposition
              </h3>
              <p className="text-muted-foreground">
                Keep your existing technology stack. No migration needed. Our platform overlays your current General Ledger, 
                providing investment reporting without the complexity and cost of traditional portfolio management systems like Addepar.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSolution;