import { Button } from "@/components/ui/button";
import { TrendingUp, Clock, Target, Shield } from "lucide-react";
import { Link } from "react-router-dom";

const FinalCTA = () => {
  const stats = [
    { icon: TrendingUp, value: "70%", label: "Cost Reduction" },
    { icon: Clock, value: "2-4 Weeks", label: "Implementation" },
    { icon: Target, value: "99.9%", label: "Data Accuracy" }
  ];

  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Ready to Transform Your Investment Reporting?
        </h2>
        <p className="text-xl mb-4 max-w-3xl mx-auto opacity-90">
          Join family offices already saving thousands in operational costs while getting better investment insights.
        </p>
        <p className="text-lg mb-12 opacity-80">
          No system changes. No migration. No risk.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Link to="/free-trial">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-6">
              Start Free Trial
            </Button>
          </Link>
          <Button size="lg" variant="outline" className="text-lg px-8 py-6 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
            Watch Demo Video
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 bg-primary-foreground/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-8 h-8 text-primary-foreground" />
              </div>
              <div className="text-3xl font-bold mb-2">{stat.value}</div>
              <div className="opacity-80">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="text-center opacity-80">
          <p className="text-sm">
            Trusted by Family Offices • Enterprise Security • 24/7 Support • SOC 2 Compliant
          </p>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;