const IntegrationsSection = () => {
  const integrations = [
    "Allvue",
    "FundCount", 
    "QuickBooks",
    "NetSuite",
    "Sage Intacct",
    "Xero"
  ];

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-foreground mb-8">
            Works with Your Existing Systems
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 max-w-4xl mx-auto">
            {integrations.map((integration, index) => (
              <div 
                key={index}
                className="flex items-center justify-center p-4 bg-background rounded-lg border shadow-sm hover:shadow-md transition-shadow"
              >
                <span className="font-semibold text-foreground text-sm">
                  {integration}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default IntegrationsSection;