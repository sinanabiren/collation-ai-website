import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import FreeTrial from "./pages/FreeTrial";
import SignIn from "./pages/SignIn";
import ScheduleDemo from "./pages/ScheduleDemo";
import BuildWorkflow from "./pages/BuildWorkflow";
import WorkflowAnalysis from "./pages/WorkflowAnalysis";
import AirflowDashboard from "./pages/AirflowDashboard";
import PowerBIDashboard from "./pages/PowerBIDashboard";
import TrialDashboard from "./pages/TrialDashboard";
import DataConnections from "./pages/DataConnections";
import DataConnectionConfig from "./pages/DataConnectionConfig";
import DataWarehouse from "./pages/DataWarehouse";
import InvestmentReporting from "./pages/InvestmentReporting";
import BuildReport from "./pages/BuildReport";
import RiskMetricsDashboard from "./pages/RiskMetricsDashboard";
import AIDashboardBuilder from "./pages/AIDashboardBuilder";
import LovableProjectSuccess from "./pages/LovableProjectSuccess";
import FinancialPlatformShowcase from "./pages/FinancialPlatformShowcase";
import ProfitTWRDashboard from "./pages/ProfitTWRDashboard";
import ExplainerDashboard from "./pages/ExplainerDashboard";
import PublicMarketEquivalentDashboard from "./pages/PublicMarketEquivalentDashboard";
import CumulativeProfitDashboard from "./pages/CumulativeProfitDashboard";
import KaplanSchoarPMEDashboard from "./pages/KaplanSchoarPMEDashboard";
import KaplanSchoarAccountDashboard from "./pages/KaplanSchoarAccountDashboard";
import DirectAlphaDashboard from "./pages/DirectAlphaDashboard";
import DirectAlphaAllocationDashboard from "./pages/DirectAlphaAllocationDashboard";
import InstitutionalPLDashboard from "./pages/InstitutionalPLDashboard";
import InstitutionalTWRDashboard from "./pages/InstitutionalTWRDashboard";
import DetailedHoldingsReport from "./pages/DetailedHoldingsReport";
import HoldingsDecomposition from "./pages/HoldingsDecomposition";
import HoldingsGeographyMap from "./pages/HoldingsGeographyMap";
import HoldingsOverTime from "./pages/HoldingsOverTime";
import PortfolioOverview from "./pages/PortfolioOverview";
import InvestmentSummary from "./pages/InvestmentSummary";
import EntityLevelFinancialSummary from "./pages/EntityLevelFinancialSummary";
import CumulativeInflowOutflowAnalysis from "./pages/CumulativeInflowOutflowAnalysis";
import InstitutionalValuationDashboard from "./pages/InstitutionalValuationDashboard";
import FixedIncomeAnalysis from "./pages/FixedIncomeAnalysis";
import CorporateStructureChart from "./pages/CorporateStructureChart";
import TransactionHistory from "./pages/TransactionHistory";
import GainLossSummary from "./pages/GainLossSummary";
import StressTestingAnalysis from "./pages/StressTestingAnalysis";
import OperationalMetricsDashboard from "./pages/OperationalMetricsDashboard";
import RegulatoryComplianceDashboard from "./pages/RegulatoryComplianceDashboard";
import ClientReportingDashboard from "./pages/ClientReportingDashboard";
import VolatilityAnalysis from "./pages/VolatilityAnalysis";
import CorrelationAnalysis from "./pages/CorrelationAnalysis";
import DrawdownAnalysis from "./pages/DrawdownAnalysis";
import SectorConcentrationRisk from "./pages/SectorConcentrationRisk";
import LiquidityAnalysis from "./pages/LiquidityAnalysis";
import RiskAttributionAnalysis from "./pages/RiskAttributionAnalysis";
import CreditRiskAssessment from "./pages/CreditRiskAssessment";
import MarketRiskAnalysis from "./pages/MarketRiskAnalysis";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/free-trial" element={<FreeTrial />} />
          <Route path="/sign-in" element={<SignIn />} />
          <Route path="/schedule-demo" element={<ScheduleDemo />} />
          <Route path="/build-workflow" element={<BuildWorkflow />} />
          <Route path="/workflow-analysis" element={<WorkflowAnalysis />} />
          <Route path="/airflow-dashboard" element={<AirflowDashboard />} />
          <Route path="/powerbi-dashboard" element={<PowerBIDashboard />} />
          <Route path="/trial-dashboard" element={<TrialDashboard />} />
          <Route path="/data-connections" element={<DataConnections />} />
          <Route path="/data-connection-config" element={<DataConnectionConfig />} />
          <Route path="/data-warehouse" element={<DataWarehouse />} />
          <Route path="/investment-reporting" element={<InvestmentReporting />} />
          <Route path="/build-report" element={<BuildReport />} />
          <Route path="/risk-metrics-dashboard" element={<RiskMetricsDashboard />} />
          <Route path="/ai-dashboard-builder" element={<AIDashboardBuilder />} />
          <Route path="/profit-twr-dashboard" element={<ProfitTWRDashboard />} />
          <Route path="/explainer-dashboard" element={<ExplainerDashboard />} />
          <Route path="/public-market-equivalent" element={<PublicMarketEquivalentDashboard />} />
          <Route path="/public-market-equivalent-dashboard" element={<PublicMarketEquivalentDashboard />} />
          <Route path="/cumulative-profit-analysis" element={<CumulativeProfitDashboard />} />
          <Route path="/cumulative-profit-dashboard" element={<CumulativeProfitDashboard />} />
          <Route path="/kaplan-schoar-pme" element={<KaplanSchoarPMEDashboard />} />
          <Route path="/kaplan-schoar-pme-dashboard" element={<KaplanSchoarPMEDashboard />} />
          <Route path="/kaplan-schoar-account" element={<KaplanSchoarAccountDashboard />} />
          <Route path="/kaplan-schoar-account-dashboard" element={<KaplanSchoarAccountDashboard />} />
          <Route path="/direct-alpha-account" element={<DirectAlphaDashboard />} />
          <Route path="/direct-alpha-dashboard" element={<DirectAlphaDashboard />} />
          <Route path="/direct-alpha-allocation" element={<DirectAlphaAllocationDashboard />} />
          <Route path="/direct-alpha-allocation-dashboard" element={<DirectAlphaAllocationDashboard />} />
          <Route path="/institutional-pl" element={<InstitutionalPLDashboard />} />
          <Route path="/institutional-pl-dashboard" element={<InstitutionalPLDashboard />} />
          <Route path="/institutional-twr" element={<InstitutionalTWRDashboard />} />
          <Route path="/institutional-twr-dashboard" element={<InstitutionalTWRDashboard />} />
          <Route path="/detailed-holdings-report" element={<DetailedHoldingsReport />} />
          <Route path="/holdings-decomposition" element={<HoldingsDecomposition />} />
          <Route path="/holdings-geography-map" element={<HoldingsGeographyMap />} />
          <Route path="/holdings-over-time" element={<HoldingsOverTime />} />
          <Route path="/portfolio-overview" element={<PortfolioOverview />} />
          <Route path="/investment-summary" element={<InvestmentSummary />} />
          <Route path="/entity-level-financial-summary" element={<EntityLevelFinancialSummary />} />
          <Route path="/cumulative-inflow-outflow-analysis" element={<CumulativeInflowOutflowAnalysis />} />
          <Route path="/institutional-valuation-dashboard" element={<InstitutionalValuationDashboard />} />
          <Route path="/fixed-income-analysis" element={<FixedIncomeAnalysis />} />
          <Route path="/corporate-structure-chart" element={<CorporateStructureChart />} />
          <Route path="/transaction-history" element={<TransactionHistory />} />
          <Route path="/gain-loss-summary" element={<GainLossSummary />} />
          <Route path="/stress-testing-analysis" element={<StressTestingAnalysis />} />
          <Route path="/operational-metrics-dashboard" element={<OperationalMetricsDashboard />} />
          <Route path="/regulatory-compliance-dashboard" element={<RegulatoryComplianceDashboard />} />
          <Route path="/client-reporting-dashboard" element={<ClientReportingDashboard />} />
          <Route path="/volatility-analysis" element={<VolatilityAnalysis />} />
          <Route path="/correlation-analysis" element={<CorrelationAnalysis />} />
          <Route path="/drawdown-analysis" element={<DrawdownAnalysis />} />
          <Route path="/sector-concentration-risk" element={<SectorConcentrationRisk />} />
          <Route path="/liquidity-analysis" element={<LiquidityAnalysis />} />
          <Route path="/risk-attribution-analysis" element={<RiskAttributionAnalysis />} />
          <Route path="/credit-risk-assessment" element={<CreditRiskAssessment />} />
          <Route path="/market-risk-analysis" element={<MarketRiskAnalysis />} />
          
          <Route path="/lovable-project-success" element={<LovableProjectSuccess />} />
          <Route path="/financial-platform-showcase" element={<FinancialPlatformShowcase />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
